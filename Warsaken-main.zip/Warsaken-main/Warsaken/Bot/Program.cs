﻿using Bot;

Setup bot = new();

bot.RunAsync().GetAwaiter().GetResult();